# lambdaSsmTest
AWS lambda test to consume Ssm Parameter Store
This is a test of a AWS Lambda that reads a parameter from the Parameter Store y the AWS Systems Manager
