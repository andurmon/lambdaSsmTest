const AWS = require("aws-sdk")
const ssm = new AWS.SSM();

exports.getParameters = async (params) => {
    return new Promise((resolve, reject) => {

        ssm.getParameters(params, (err, data) => {
            if (err) {
                console.log(err, err.stack);
                reject(err);
                return;
            }
            console.log("Parameters", data);
            resolve(data);
            return;
        });

    })
}

exports.getParameter = async (params,) => {
    return new Promise((resolve, reject) => {
        ssm.getParameter(params, (error, data) => {
            if (error) {
                console.log("Error getting parameters", error)
                reject(error)
                return
            }

            console.log("Parameter: ", data)
            resolve(data);
            return;

        });
    })
}