const { handler } = require("./index")


handler({})